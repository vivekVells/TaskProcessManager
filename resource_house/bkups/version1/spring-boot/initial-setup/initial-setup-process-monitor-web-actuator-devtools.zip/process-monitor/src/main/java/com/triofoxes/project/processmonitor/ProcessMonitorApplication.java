package com.triofoxes.project.processmonitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcessMonitorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcessMonitorApplication.class, args);
	}
}
